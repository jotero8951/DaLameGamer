﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoardMovement : MonoBehaviour
{
    //
    Vector3 playerPos;
    public Transform destination;
    public Transform death;
   

    // Start is called before the first frame update
    void Start()
    {
        playerPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            playerPos += transform.forward;

        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            playerPos -= transform.forward ;
          
        }
    
    if (Input.GetKeyDown(KeyCode.D))
        {
            playerPos += transform.right ;

        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            playerPos -= transform.right;
        }
        if(playerPos.x == destination.transform.position.x)
        
        {
            playerPos += transform.up;
        }
        if (playerPos.x == death.transform.position.x)
        {
            Destroy(this.gameObject);
            Debug.Log("You Lose");
        }
        transform.position = playerPos;
    }
}
